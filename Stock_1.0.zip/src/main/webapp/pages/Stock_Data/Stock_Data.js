Application.$controller("Stock_DataPageController", ["$scope", function($scope) {
    "use strict";

    /* perform any action with the variables inside this block(on-page-load) */
    $scope.onPageVariablesReady = function() {
        /*
         * variables can be accessed through '$scope.Variables' property here
         * e.g. $scope.Variables.staticVariable1.getData()
         */
        //        $scope.Variables.API_stock_Data_by_Symbol.update();

    };

    /* perform any action with widgets inside this block */
    $scope.onPageReady = function() {
        /*
         * widgets can be accessed through '$scope.Widgets' property here
         * e.g. $scope.Widgets.byId(), $scope.Widgets.byName()or access widgets by $scope.Widgets.widgetName
         */

    };


    $scope.segmented_control1BeforeSegmentChange = function($isolateScope, $old, $new) {
        var temp = 0;
        var date = new Date();
        switch ($new) {
            case 0:
                temp = 10;
                break;
            case 1:
                temp = 17;
                break;
            case 2:
                temp = 30;
                break;
            case 3:
                temp = 90;
                break;
            case 4:
                temp = 180;
                break;
            case 5:
                temp = 400;
                break;
        }

        date.setDate(date.getDate() - temp);
        date = date.toISOString().split('T')[0];
        $scope.Variables.selected_date.dataSet.dataValue = date.toString();
        //alert($scope.Variables.query.dataSet.dataValue);
        //      alert($scope.Variables.Symbol.dataSet.dataValue);
        $scope.Variables.API_stock_data_for_graph.update();
        // alert("updated")
    };

}]);