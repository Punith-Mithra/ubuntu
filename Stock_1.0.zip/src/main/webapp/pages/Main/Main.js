Application.$controller("MainPageController", ["$scope", "$filter", function($scope, $filter) {
    "use strict";
    var selectedItem = [];

    /* perform any action with the variables inside this block(on-page-load) */
    $scope.onPageVariablesReady = function() {
        /*
         * variables can be accessed through '$scope.Variables' property here
         * e.g. $scope.Variables.staticVariable1.getData()
         */
        var selectedDate = new Date();
        selectedDate.setDate(selectedDate.getDate() - 10);
        $scope.Variables.selected_date.dataSet.dataValue = $filter('date')(selectedDate, 'yyyy-MM-dd');
        $scope.Variables.current_date.dataSet.dataValue = $filter('date')(new Date(), 'yyyy-MM-dd');
    };

    /* perform any action with widgets inside this block */
    $scope.onPageReady = function() {
        /*
         * widgets can be accessed through '$scope.Widgets' property here
         * e.g. $scope.Widgets.byId(), $scope.Widgets.byName()or access widgets by $scope.Widgets.widgetName
         */
    };


    $scope.segmentControlBeforeSegmentChange = function($isolateScope, $old, $new) {

        $new === 1 ? $scope.Widgets.portfolioMenu.show = true : $scope.Widgets.portfolioMenu.show = false
        if ($new === 0) {
            $scope.Widgets.mobile_navbar1.title = "MARKET";
        } else if ($new === 1) {
            $scope.Widgets.mobile_navbar1.title = "MY PORTFOLIO";
        } else if ($new === 2) {
            $scope.Widgets.mobile_navbar1.title = "MY WISHLIST";
        }
    };

    $scope.favLiveListClick = function($event, $isolateScope) {

        $scope.Variables.Symbol.dataSet.dataValue = $scope.Widgets.favLiveList.selecteditem.symbol;
    };


    $scope.myStockListClick = function($event, $isolateScope) {
        $scope.Variables.Symbol.dataSet.dataValue = $scope.Widgets.myStockList.selecteditem.symbol;
    };

    $scope.container3Click = function($event, $isolateScope) {

        selectedItem.push(this.item);


    };



}]);