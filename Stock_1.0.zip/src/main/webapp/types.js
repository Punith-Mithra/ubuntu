wm.types = {
	"types": {
		"API_Query.RootResponse": {
			"service": "API_Query",
			"liveService": false,
			"internal": false,
			"fields": {
				"query": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "API_Query.query",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				}
			}
		},
		"API_Query.cacheEntryItem": {
			"service": "API_Query",
			"liveService": false,
			"internal": false,
			"fields": {
				"content": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"execution-start-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 5,
					"noChange": [],
					"include": []
				},
				"execution-stop-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"execution-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"method": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				},
				"type": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				}
			}
		},
		"API_Query.diagnostics": {
			"service": "API_Query",
			"liveService": false,
			"internal": false,
			"fields": {
				"build-version": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				},
				"cache": {
					"isList": true,
					"fieldSubType": null,
					"exclude": [],
					"type": "API_Query.cacheEntryItem",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"javascript": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "API_Query.javascript",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"publiclyCallable": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 5,
					"noChange": [],
					"include": []
				},
				"query": {
					"isList": true,
					"fieldSubType": null,
					"exclude": [],
					"type": "API_Query.queryEntryItem",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				},
				"service-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"url": {
					"isList": true,
					"fieldSubType": null,
					"exclude": [],
					"type": "API_Query.urlEntryItem",
					"required": true,
					"fieldOrder": 7,
					"noChange": [],
					"include": []
				},
				"user-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 6,
					"noChange": [],
					"include": []
				}
			}
		},
		"API_Query.javascript": {
			"service": "API_Query",
			"liveService": false,
			"internal": false,
			"fields": {
				"execution-start-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"execution-stop-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"execution-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				},
				"instructions-used": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"table-name": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				}
			}
		},
		"API_Query.query": {
			"service": "API_Query",
			"liveService": false,
			"internal": false,
			"fields": {
				"count": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.Integer",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"created": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				},
				"diagnostics": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "API_Query.diagnostics",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				},
				"lang": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"results": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "API_Query.results",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				}
			}
		},
		"API_Query.queryEntryItem": {
			"service": "API_Query",
			"liveService": false,
			"internal": false,
			"fields": {
				"content": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"execution-start-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"execution-stop-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"execution-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				},
				"params": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				}
			}
		},
		"API_Query.quoteEntryItem": {
			"service": "API_Query",
			"liveService": false,
			"internal": false,
			"fields": {
				"Adj_Close": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				},
				"Close": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				},
				"Date": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"High": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 7,
					"noChange": [],
					"include": []
				},
				"Low": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"Open": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"Symbol": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 6,
					"noChange": [],
					"include": []
				},
				"Volume": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 5,
					"noChange": [],
					"include": []
				}
			}
		},
		"API_Query.results": {
			"service": "API_Query",
			"liveService": false,
			"internal": false,
			"fields": {
				"quote": {
					"isList": true,
					"fieldSubType": null,
					"exclude": [],
					"type": "API_Query.quoteEntryItem",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				}
			}
		},
		"API_Query.urlEntryItem": {
			"service": "API_Query",
			"liveService": false,
			"internal": false,
			"fields": {
				"content": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"execution-start-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				},
				"execution-stop-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"execution-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				}
			}
		},
		"boolean": {
			"primitiveType": "Boolean",
			"internal": true
		},
		"byte": {
			"primitiveType": "Number",
			"internal": true
		},
		"char": {
			"primitiveType": "String",
			"internal": true
		},
		"com.stock.stock_db.MyStocks": {
			"service": "Stock_DB",
			"liveService": false,
			"internal": false,
			"fields": {
				"category": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.Integer",
					"required": false,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"exchange": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": false,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				},
				"name": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": false,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"sid": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.Integer",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"symbol": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": false,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				}
			}
		},
		"double": {
			"primitiveType": "Number",
			"internal": true
		},
		"float": {
			"primitiveType": "Number",
			"internal": true
		},
		"int": {
			"primitiveType": "Number",
			"internal": true
		},
		"java.lang.Boolean": {
			"primitiveType": "Boolean",
			"internal": false
		},
		"java.lang.Byte": {
			"primitiveType": "Number",
			"internal": false
		},
		"java.lang.Character": {
			"primitiveType": "String",
			"internal": false
		},
		"java.lang.Double": {
			"primitiveType": "Number",
			"internal": false
		},
		"java.lang.Float": {
			"primitiveType": "Number",
			"internal": false
		},
		"java.lang.Integer": {
			"primitiveType": "Number",
			"internal": false
		},
		"java.lang.Long": {
			"primitiveType": "Number",
			"internal": false
		},
		"java.lang.Short": {
			"primitiveType": "Number",
			"internal": false
		},
		"java.lang.String": {
			"primitiveType": "String",
			"internal": false
		},
		"java.lang.StringBuffer": {
			"primitiveType": "String",
			"internal": false
		},
		"java.math.BigDecimal": {
			"primitiveType": "Number",
			"internal": false
		},
		"java.math.BigInteger": {
			"primitiveType": "Number",
			"internal": false
		},
		"java.sql.Date": {
			"primitiveType": "Date",
			"internal": false
		},
		"java.sql.Time": {
			"primitiveType": "Date",
			"internal": false
		},
		"java.sql.Timestamp": {
			"primitiveType": "Date",
			"internal": false
		},
		"java.util.Date": {
			"primitiveType": "Date",
			"internal": false
		},
		"long": {
			"primitiveType": "Number",
			"internal": true
		},
		"look_up.RootResponse": {
			"service": "look_up",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"markitondemand_lookup.LookupResultEntryItem": {
			"service": "markitondemand_lookup",
			"liveService": false,
			"internal": false,
			"fields": {
				"Exchange": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"Name": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"Symbol": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				}
			}
		},
		"markitondemand_lookup.LookupResultList": {
			"service": "markitondemand_lookup",
			"liveService": false,
			"internal": false,
			"fields": {
				"LookupResult": {
					"isList": true,
					"fieldSubType": null,
					"exclude": [],
					"type": "markitondemand_lookup.LookupResultEntryItem",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				}
			}
		},
		"org.joda.time.LocalDateTime": {
			"primitiveType": "DateTime",
			"internal": true
		},
		"short": {
			"primitiveType": "Number",
			"internal": true
		},
		"yahooapis.AfterHoursChangeRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.AnnualizedGain": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.AskRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.BidRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.ChangePercentRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.ChangeRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.Commission": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.DaysRangeRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.DaysValueChange": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.DaysValueChangeRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.DividendPayDate": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.DividendShare": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.DividendYield": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.ErrorIndicationreturnedforsymbolchangedinvalid": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.ExDividendDate": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.HighLimit": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.HoldingsGain": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.HoldingsGainPercent": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.HoldingsGainPercentRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.HoldingsGainRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.HoldingsValue": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.HoldingsValueRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.LastTradeRealtimeWithTime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.LowLimit": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.MarketCapRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.MoreInfo": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.Notes": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.OrderBookRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.PERatioRealtime": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.PricePaid": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.RootResponse": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
				"query": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.query",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				}
			}
		},
		"yahooapis.SharesOwned": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.TickerTrend": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.TradeDate": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
			}
		},
		"yahooapis.cache": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
				"content": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"execution-start-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 5,
					"noChange": [],
					"include": []
				},
				"execution-stop-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"execution-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"method": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				},
				"type": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				}
			}
		},
		"yahooapis.diagnostics": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
				"build-version": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				},
				"cache": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.cache",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"javascript": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.javascript",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"publiclyCallable": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 5,
					"noChange": [],
					"include": []
				},
				"query": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.query",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				},
				"service-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"url": {
					"isList": true,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.urlEntryItem",
					"required": true,
					"fieldOrder": 7,
					"noChange": [],
					"include": []
				},
				"user-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 6,
					"noChange": [],
					"include": []
				}
			}
		},
		"yahooapis.javascript": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
				"execution-start-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"execution-stop-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"execution-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				},
				"instructions-used": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"table-name": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				}
			}
		},
		"yahooapis.query": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
				"content": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"count": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.Integer",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				},
				"created": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"diagnostics": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.diagnostics",
					"required": true,
					"fieldOrder": 7,
					"noChange": [],
					"include": []
				},
				"execution-start-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 9,
					"noChange": [],
					"include": []
				},
				"execution-stop-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"execution-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 6,
					"noChange": [],
					"include": []
				},
				"lang": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 8,
					"noChange": [],
					"include": []
				},
				"params": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 5,
					"noChange": [],
					"include": []
				},
				"results": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.results",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				}
			}
		},
		"yahooapis.quote": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
				"AfterHoursChangeRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.AfterHoursChangeRealtime",
					"required": true,
					"fieldOrder": 33,
					"noChange": [],
					"include": []
				},
				"AnnualizedGain": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.AnnualizedGain",
					"required": true,
					"fieldOrder": 10,
					"noChange": [],
					"include": []
				},
				"Ask": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 63,
					"noChange": [],
					"include": []
				},
				"AskRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.AskRealtime",
					"required": true,
					"fieldOrder": 20,
					"noChange": [],
					"include": []
				},
				"AverageDailyVolume": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 41,
					"noChange": [],
					"include": []
				},
				"Bid": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				},
				"BidRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.BidRealtime",
					"required": true,
					"fieldOrder": 36,
					"noChange": [],
					"include": []
				},
				"BookValue": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				},
				"Change": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 27,
					"noChange": [],
					"include": []
				},
				"ChangeFromFiftydayMovingAverage": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 6,
					"noChange": [],
					"include": []
				},
				"ChangeFromTwoHundreddayMovingAverage": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 15,
					"noChange": [],
					"include": []
				},
				"ChangeFromYearHigh": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 45,
					"noChange": [],
					"include": []
				},
				"ChangeFromYearLow": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 65,
					"noChange": [],
					"include": []
				},
				"ChangePercentRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.ChangePercentRealtime",
					"required": true,
					"fieldOrder": 75,
					"noChange": [],
					"include": []
				},
				"ChangeRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.ChangeRealtime",
					"required": true,
					"fieldOrder": 57,
					"noChange": [],
					"include": []
				},
				"Change_PercentChange": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 11,
					"noChange": [],
					"include": []
				},
				"ChangeinPercent": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 81,
					"noChange": [],
					"include": []
				},
				"Commission": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.Commission",
					"required": true,
					"fieldOrder": 72,
					"noChange": [],
					"include": []
				},
				"Currency": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 23,
					"noChange": [],
					"include": []
				},
				"DaysHigh": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"DaysLow": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 51,
					"noChange": [],
					"include": []
				},
				"DaysRange": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 7,
					"noChange": [],
					"include": []
				},
				"DaysRangeRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.DaysRangeRealtime",
					"required": true,
					"fieldOrder": 12,
					"noChange": [],
					"include": []
				},
				"DaysValueChange": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.DaysValueChange",
					"required": true,
					"fieldOrder": 53,
					"noChange": [],
					"include": []
				},
				"DaysValueChangeRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.DaysValueChangeRealtime",
					"required": true,
					"fieldOrder": 73,
					"noChange": [],
					"include": []
				},
				"DividendPayDate": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.DividendPayDate",
					"required": true,
					"fieldOrder": 22,
					"noChange": [],
					"include": []
				},
				"DividendShare": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.DividendShare",
					"required": true,
					"fieldOrder": 66,
					"noChange": [],
					"include": []
				},
				"DividendYield": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.DividendYield",
					"required": true,
					"fieldOrder": 16,
					"noChange": [],
					"include": []
				},
				"EBITDA": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 67,
					"noChange": [],
					"include": []
				},
				"EPSEstimateCurrentYear": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 17,
					"noChange": [],
					"include": []
				},
				"EPSEstimateNextQuarter": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 38,
					"noChange": [],
					"include": []
				},
				"EPSEstimateNextYear": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 60,
					"noChange": [],
					"include": []
				},
				"EarningsShare": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 77,
					"noChange": [],
					"include": []
				},
				"ErrorIndicationreturnedforsymbolchangedinvalid": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.ErrorIndicationreturnedforsymbolchangedinvalid",
					"required": true,
					"fieldOrder": 8,
					"noChange": [],
					"include": []
				},
				"ExDividendDate": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.ExDividendDate",
					"required": true,
					"fieldOrder": 58,
					"noChange": [],
					"include": []
				},
				"FiftydayMovingAverage": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 49,
					"noChange": [],
					"include": []
				},
				"HighLimit": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.HighLimit",
					"required": true,
					"fieldOrder": 54,
					"noChange": [],
					"include": []
				},
				"HoldingsGain": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.HoldingsGain",
					"required": true,
					"fieldOrder": 30,
					"noChange": [],
					"include": []
				},
				"HoldingsGainPercent": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.HoldingsGainPercent",
					"required": true,
					"fieldOrder": 26,
					"noChange": [],
					"include": []
				},
				"HoldingsGainPercentRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.HoldingsGainPercentRealtime",
					"required": true,
					"fieldOrder": 34,
					"noChange": [],
					"include": []
				},
				"HoldingsGainRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.HoldingsGainRealtime",
					"required": true,
					"fieldOrder": 69,
					"noChange": [],
					"include": []
				},
				"HoldingsValue": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.HoldingsValue",
					"required": true,
					"fieldOrder": 64,
					"noChange": [],
					"include": []
				},
				"HoldingsValueRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.HoldingsValueRealtime",
					"required": true,
					"fieldOrder": 76,
					"noChange": [],
					"include": []
				},
				"LastTradeDate": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 18,
					"noChange": [],
					"include": []
				},
				"LastTradePriceOnly": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 37,
					"noChange": [],
					"include": []
				},
				"LastTradeRealtimeWithTime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.LastTradeRealtimeWithTime",
					"required": true,
					"fieldOrder": 74,
					"noChange": [],
					"include": []
				},
				"LastTradeTime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 50,
					"noChange": [],
					"include": []
				},
				"LastTradeWithTime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 44,
					"noChange": [],
					"include": []
				},
				"LowLimit": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.LowLimit",
					"required": true,
					"fieldOrder": 13,
					"noChange": [],
					"include": []
				},
				"MarketCapRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.MarketCapRealtime",
					"required": true,
					"fieldOrder": 40,
					"noChange": [],
					"include": []
				},
				"MarketCapitalization": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 35,
					"noChange": [],
					"include": []
				},
				"MoreInfo": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.MoreInfo",
					"required": true,
					"fieldOrder": 9,
					"noChange": [],
					"include": []
				},
				"Name": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 71,
					"noChange": [],
					"include": []
				},
				"Notes": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.Notes",
					"required": true,
					"fieldOrder": 29,
					"noChange": [],
					"include": []
				},
				"OneyrTargetPrice": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 56,
					"noChange": [],
					"include": []
				},
				"Open": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"OrderBookRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.OrderBookRealtime",
					"required": true,
					"fieldOrder": 5,
					"noChange": [],
					"include": []
				},
				"PEGRatio": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 70,
					"noChange": [],
					"include": []
				},
				"PERatio": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 39,
					"noChange": [],
					"include": []
				},
				"PERatioRealtime": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.PERatioRealtime",
					"required": true,
					"fieldOrder": 46,
					"noChange": [],
					"include": []
				},
				"PercebtChangeFromYearHigh": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 68,
					"noChange": [],
					"include": []
				},
				"PercentChange": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 21,
					"noChange": [],
					"include": []
				},
				"PercentChangeFromFiftydayMovingAverage": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 28,
					"noChange": [],
					"include": []
				},
				"PercentChangeFromTwoHundreddayMovingAverage": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 14,
					"noChange": [],
					"include": []
				},
				"PercentChangeFromYearLow": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 42,
					"noChange": [],
					"include": []
				},
				"PreviousClose": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 48,
					"noChange": [],
					"include": []
				},
				"PriceBook": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 78,
					"noChange": [],
					"include": []
				},
				"PriceEPSEstimateCurrentYear": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"PriceEPSEstimateNextYear": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 52,
					"noChange": [],
					"include": []
				},
				"PricePaid": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.PricePaid",
					"required": true,
					"fieldOrder": 62,
					"noChange": [],
					"include": []
				},
				"PriceSales": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 82,
					"noChange": [],
					"include": []
				},
				"SharesOwned": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.SharesOwned",
					"required": true,
					"fieldOrder": 80,
					"noChange": [],
					"include": []
				},
				"ShortRatio": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 79,
					"noChange": [],
					"include": []
				},
				"StockExchange": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 47,
					"noChange": [],
					"include": []
				},
				"Symbol": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 32,
					"noChange": [],
					"include": []
				},
				"TickerTrend": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.TickerTrend",
					"required": true,
					"fieldOrder": 43,
					"noChange": [],
					"include": []
				},
				"TradeDate": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.TradeDate",
					"required": true,
					"fieldOrder": 55,
					"noChange": [],
					"include": []
				},
				"TwoHundreddayMovingAverage": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 19,
					"noChange": [],
					"include": []
				},
				"Volume": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 61,
					"noChange": [],
					"include": []
				},
				"YearHigh": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 31,
					"noChange": [],
					"include": []
				},
				"YearLow": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 59,
					"noChange": [],
					"include": []
				},
				"YearRange": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 24,
					"noChange": [],
					"include": []
				},
				"symbol": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 25,
					"noChange": [],
					"include": []
				}
			}
		},
		"yahooapis.results": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
				"quote": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "yahooapis.quote",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				}
			}
		},
		"yahooapis.urlEntryItem": {
			"service": "yahooapis",
			"liveService": false,
			"internal": false,
			"fields": {
				"content": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 0,
					"noChange": [],
					"include": []
				},
				"execution-start-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 4,
					"noChange": [],
					"include": []
				},
				"execution-stop-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 1,
					"noChange": [],
					"include": []
				},
				"execution-time": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 3,
					"noChange": [],
					"include": []
				},
				"proxy": {
					"isList": false,
					"fieldSubType": null,
					"exclude": [],
					"type": "java.lang.String",
					"required": true,
					"fieldOrder": 2,
					"noChange": [],
					"include": []
				}
			}
		}
	}
};