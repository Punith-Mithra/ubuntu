echo "enter a word"

read word

case $word in

[aeiou]* | [AEIOU]*)
	
	echo "the word begins with a vowel." 
	;;

[0-9]*) 
	echo "the first char begins with a digit"
	;;
 
*[0-9])
	echo "the last char is a digit"
	;;

???) 
	echo "you entered a three numberd word"
	;;

*)
	echo "i dono what u enterd"
	;;
esac
