chmod 744 $1
ls -l $1
