# this is my first shell script 
echo hello world
