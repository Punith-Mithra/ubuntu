# thi si smy second scrip y file :: 

pwd
ls -l 
banner "The End"
