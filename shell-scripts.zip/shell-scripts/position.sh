mv $1 $2

cat $2
